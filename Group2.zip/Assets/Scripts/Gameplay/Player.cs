using UnityEngine;

public class Player : MonoBehaviour
{
    [SerializeField][Range(1, 10)] private float _speed = 1f;
    private string _text = "Message";
    
    private float _timer = 0f;
    private GameLogic _logic;

    private void Awake()
    {
        _logic = new GameLogic(GetComponent<Rigidbody>());
    }

    void Update()
    {
        _timer += Time.deltaTime;

        if (_timer > 5f)
        {
            _timer = 0f;
            _logic.DoSomething();
        }
        var directionalH = Input.GetAxis("Horizontal");
        var directianalV = Input.GetAxis("Vertical");

        transform.position += (Vector3.forward * directianalV + Vector3.right * directionalH) * _speed * Time.deltaTime;
    }
}
